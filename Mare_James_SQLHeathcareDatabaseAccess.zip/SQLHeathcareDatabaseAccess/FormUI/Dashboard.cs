﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI {
    public partial class Dashboard : Form {
        List<Patient> patients = new List<Patient>();

        public Dashboard() {
            InitializeComponent();

            UpdateBinding();
        }

        private void UpdateBinding() {
            PatientsFoundListbox.DataSource = patients;
            PatientsFoundListbox.DisplayMember = "FullInfo";
        }


        private void SearchButton_Click(object sender, EventArgs e) {
            DataAccess db = new DataAccess();

            patients = db.GetPatients(LastNameText.Text);

            UpdateBinding();
        }

        private void InsertRecordButton_Click(object sender, EventArgs e) {
            DataAccess db = new DataAccess();

            string suffix = NameSuffixInsTextBox.Text, MiddleName = MiddleNameInsTextBox.Text;

			// check if either of the following are empty and should then be null
			// meant to lessen casses for potentially null that are carried out in DataAccess.cs
			if (string.IsNullOrEmpty(suffix))
				suffix = null;
			if (string.IsNullOrEmpty(MiddleName))
                MiddleName = null;

			db.InsetPatient(int.Parse(HSPIdInsTextBox.Text), int.Parse(LocationIdInsTextBox.Text), suffix,
                                FirstNameInsTextBox.Text, MiddleName, LastNameInsTextBox.Text,
								SSNInsTextBox.Text, GenderInsTextBox.Text, int.Parse(AgeInsTextBox.Text),
                                DOBInsTextBox.Text, int.Parse(WeightInLbsInsTextBox.Text), int.Parse(HeightOnlyInInchesInsTextBox.Text),
                                InsuranceInsTextBox.Text, DODInsTextBox.Text, PrimaryPhoneInsTextBox.Text,
                                SecondaryPhoneInsTextBox.Text, EmergencyContactPhoneInsTextBox.Text, StreetAddrInsTextBox.Text,
                                CityAddrInsTextBox.Text, StateAbbreviationAddrInsTextBox.Text, ZipCodeAddrInsTextBox.Text);

            // Reset all TextBox values
            HSPIdInsTextBox.Text = null;
            LocationIdInsTextBox.Text = null;
            NameSuffixInsTextBox.Text = null;
            FirstNameInsTextBox.Text = null;
            MiddleNameInsTextBox.Text = null;
            LastNameInsTextBox.Text = null;
            SSNInsTextBox.Text = null;
            GenderInsTextBox.Text = null;
            AgeInsTextBox.Text = null;
            DOBInsTextBox.Text = null;
            WeightInLbsInsTextBox.Text = null;
            HeightOnlyInInchesInsTextBox.Text = null;
            InsuranceInsTextBox.Text = null;
            DODInsTextBox.Text = null;
            PrimaryPhoneInsTextBox.Text = null;
            SecondaryPhoneInsTextBox.Text = null;
            EmergencyContactPhoneInsTextBox.Text = null;
            StreetAddrInsTextBox.Text = null;
            CityAddrInsTextBox.Text = null;
            StateAbbreviationAddrInsTextBox.Text = null;
            ZipCodeAddrInsTextBox.Text = null;
        }

    }
}
