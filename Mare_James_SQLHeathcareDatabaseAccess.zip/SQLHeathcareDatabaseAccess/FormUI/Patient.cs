﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI {//https://www.youtube.com/watch?v=Et2khGnrIqc&t=3783s
    public class Patient {
        public int PatientId { get; set; }
        public int HSP_Id { get; set; }
        public int LocationId { get; set; }
        public string NameSuffix { get; set; }
        public string FName { get; set; }
        public string MName { get; set; }
        public string LName { get; set; }
        public string SSN { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }
        public string DOB { get; set; }
        public int WeightInLbs { get; set; }
        public int HeightOnlyInInches { get; set; }
        public string Insurance { get; set; }
        public string DOD { get; set; }
        public string PrimaryPhone { get; set; }
        public string SecondaryPhone { get; set; }
        public string EmergencyContactPhone { get; set; }
        public string StreetAddr { get; set; }
        public string CityAddr { get; set; }
        public string StateAbbreviationAddr { get; set; }
        public string ZipCodeAddr { get; set; }

        public string FullInfo {
            get {
                if (string.IsNullOrEmpty(NameSuffix)) // "[PatientId] FName MName LName"
                    return $"[{ PatientId }] { FName } { MName } { LName }";

                // "[PatientId] (NameSuffix) FName MName LName"
                return $"[{ PatientId }] ({ NameSuffix }) { FName } { MName } { LName }";
            }
        }

    }
}
