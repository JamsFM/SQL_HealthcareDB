﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace FormUI {
    public class DataAccess {
        // Reading from SQL
        public List<Patient> GetPatients(string LastName /*int Patientid*/) {
            //throw new NotImplementedException(); // temp filler
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("TCSS455HealthcareDB"))) {
                
				try { // Test database connectablity
					connection.Open();
				} catch (System.Data.SqlClient.SqlException ex) {
					Console.WriteLine("Could not connect to Mare_James_db Database" + "\n" + ex);
					System.Windows.Forms.Application.Exit(); // exit application upon failing to connect
				}
				
				// Usefull for when you have a SQL Stored Procedure
                //var result = connection.Query<Patient>("dbo.People_GetByLastName @LName", new { LName = LastName }).ToList();
                var result = connection.Query<Patient>($"SELECT * FROM Patients WHERE LName = '{ LastName }'").ToList();
                return result;
            }
        }

        // Writing from SQL
        public void InsetPatient(int hsp_Id, int locationId, string suffix, string FirstName, string MiddleName, string LastName, string ssn, string gender, int age, string dob, int weight, int height, string insurance, string dod, string primaryPhone, string secondaryPhone, string emergencyContactPhone, string street, string city, string stateAbbr, string zipCode) {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("TCSS455HealthcareDB"))) {
                List<Patient> patients = new List<Patient>();

                patients.Add(new Patient { HSP_Id = hsp_Id, LocationId = locationId, NameSuffix = suffix, FName = FirstName, MName = MiddleName, LName = LastName , SSN = ssn, Gender = gender, DOB = dob, WeightInLbs = weight, HeightOnlyInInches = height, Insurance = insurance, DOD = dod, PrimaryPhone = primaryPhone, SecondaryPhone = secondaryPhone, EmergencyContactPhone = emergencyContactPhone, StreetAddr = street, CityAddr = city, StateAbbreviationAddr = stateAbbr, ZipCodeAddr = zipCode });

				try { // Test database connectablity
					connection.Open();
				} catch (System.Data.SqlClient.SqlException ex) {
					Console.WriteLine("Could not connect to Mare_James_db Database" + "\n" + ex);
					System.Windows.Forms.Application.Exit(); // exit application upon failing to connect
				}

				// Usefull for when you have a SQL Stored Procedure
				//connection.Execute("dbo.People_Insert @Salutaion, @FName, @MName, @LName", patients);

				if (string.IsNullOrEmpty(ssn)) {
					if (string.IsNullOrEmpty(dod)) { // If both ssn & dod should be null
						connection.Execute($"INSERT INTO Patients VALUES('{ hsp_Id }', '{ locationId }', '{ suffix }', '{ FirstName }', '{ MiddleName }', '{ LastName }', NULL, '{ gender }', '{ age }', '{ dob }', '{ weight }', '{ height }', '{ insurance }', NULL, '{ primaryPhone }', '{ secondaryPhone }', '{ emergencyContactPhone }', '{ street }', '{ city }', '{ stateAbbr }', '{ zipCode }')");
						return;
					} // If only ssn should be null
					connection.Execute($"INSERT INTO Patients VALUES('{ hsp_Id }', '{ locationId }', '{ suffix }', '{ FirstName }', '{ MiddleName }', '{ LastName }', NULL, '{ gender }', '{ age }', '{ dob }', '{ weight }', '{ height }', '{ insurance }', '{ dod }', '{ primaryPhone }', '{ secondaryPhone }', '{ emergencyContactPhone }', '{ street }', '{ city }', '{ stateAbbr }', '{ zipCode }')");
					return;
				} else if (string.IsNullOrEmpty(dod)) { // If dod should be null
					connection.Execute($"INSERT INTO Patients VALUES('{ hsp_Id }', '{ locationId }', '{ suffix }', '{ FirstName }', '{ MiddleName }', '{ LastName }', '{ ssn }', '{ gender }', '{ age }', '{ dob }', '{ weight }', '{ height }', '{ insurance }', NULL, '{ primaryPhone }', '{ secondaryPhone }', '{ emergencyContactPhone }', '{ street }', '{ city }', '{ stateAbbr }', '{ zipCode }')");
					return;
				}
				// Neither ssn nor dod should be null
				connection.Execute($"INSERT INTO Patients VALUES('{ hsp_Id }', '{ locationId }', '{ suffix }', '{ FirstName }', '{ MiddleName }', '{ LastName }', '{ ssn }', '{ gender }', '{ age }', '{ dob }', '{ weight }', '{ height }', '{ insurance }', '{ dod }', '{ primaryPhone }', '{ secondaryPhone }', '{ emergencyContactPhone }', '{ street }', '{ city }', '{ stateAbbr }', '{ zipCode }')");
			}
		}
    }
}
