﻿namespace FormUI
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PatientsFoundListbox = new System.Windows.Forms.ListBox();
            this.LastNameText = new System.Windows.Forms.TextBox();
            this.LastNameLabel = new System.Windows.Forms.Label();
            this.SearchButton = new System.Windows.Forms.Button();
            this.FirstNameInsLabel = new System.Windows.Forms.Label();
            this.FirstNameInsTextBox = new System.Windows.Forms.TextBox();
            this.MiddleNameInsLabel = new System.Windows.Forms.Label();
            this.MiddleNameInsTextBox = new System.Windows.Forms.TextBox();
            this.NameSuffixInsLabel = new System.Windows.Forms.Label();
            this.NameSuffixInsTextBox = new System.Windows.Forms.TextBox();
            this.LastNameInsLabel = new System.Windows.Forms.Label();
            this.LastNameInsTextBox = new System.Windows.Forms.TextBox();
            this.InsertRecordButton = new System.Windows.Forms.Button();
            this.HSPIdInsLabel = new System.Windows.Forms.Label();
            this.HSPIdInsTextBox = new System.Windows.Forms.TextBox();
            this.GenderInsLabel = new System.Windows.Forms.Label();
            this.GenderInsTextBox = new System.Windows.Forms.TextBox();
            this.SSNInsLabel = new System.Windows.Forms.Label();
            this.SSNInsTextBox = new System.Windows.Forms.TextBox();
            this.LocationIdInsLabel = new System.Windows.Forms.Label();
            this.LocationIdInsTextBox = new System.Windows.Forms.TextBox();
            this.PrimaryPhoneInsLabel = new System.Windows.Forms.Label();
            this.PrimaryPhoneInsTextBox = new System.Windows.Forms.TextBox();
            this.DODInsLabel = new System.Windows.Forms.Label();
            this.DODInsTextBox = new System.Windows.Forms.TextBox();
            this.AgeInsLabel = new System.Windows.Forms.Label();
            this.AgeInsTextBox = new System.Windows.Forms.TextBox();
            this.DOBInsLabel = new System.Windows.Forms.Label();
            this.DOBInsTextBox = new System.Windows.Forms.TextBox();
            this.InsuranceInsLabel = new System.Windows.Forms.Label();
            this.InsuranceInsTextBox = new System.Windows.Forms.TextBox();
            this.HeightOnlyInInchesInsLabel = new System.Windows.Forms.Label();
            this.HeightOnlyInInchesInsTextBox = new System.Windows.Forms.TextBox();
            this.WeightInLbsInsLabel = new System.Windows.Forms.Label();
            this.WeightInLbsInsTextBox = new System.Windows.Forms.TextBox();
            this.SecondaryPhoneInsLabel = new System.Windows.Forms.Label();
            this.SecondaryPhoneInsTextBox = new System.Windows.Forms.TextBox();
            this.EmergencyContactPhoneInsLabel = new System.Windows.Forms.Label();
            this.EmergencyContactPhoneInsTextBox = new System.Windows.Forms.TextBox();
            this.StreetAddrInsLabel = new System.Windows.Forms.Label();
            this.StreetAddrInsTextBox = new System.Windows.Forms.TextBox();
            this.CityAddrInsLabel = new System.Windows.Forms.Label();
            this.CityAddrInsTextBox = new System.Windows.Forms.TextBox();
            this.StateAbbreviationAddrInsLabel = new System.Windows.Forms.Label();
            this.StateAbbreviationAddrInsTextBox = new System.Windows.Forms.TextBox();
            this.ZipCodeAddrInsLabel = new System.Windows.Forms.Label();
            this.ZipCodeAddrInsTextBox = new System.Windows.Forms.TextBox();
            this.PatientAddressInfoLabel = new System.Windows.Forms.Label();
            this.PatientContactInfoLabel = new System.Windows.Forms.Label();
            this.PatientPatientInfoLabel = new System.Windows.Forms.Label();
            this.NewPatientLabel = new System.Windows.Forms.Label();
            this.SearchForExistingPatientsLabel = new System.Windows.Forms.Label();
            this.ContactLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SearchResultsLabel = new System.Windows.Forms.Label();
            this.BlueNoticeLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // PatientsFoundListbox
            // 
            this.PatientsFoundListbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PatientsFoundListbox.FormattingEnabled = true;
            this.PatientsFoundListbox.ItemHeight = 24;
            this.PatientsFoundListbox.Location = new System.Drawing.Point(17, 106);
            this.PatientsFoundListbox.Name = "PatientsFoundListbox";
            this.PatientsFoundListbox.Size = new System.Drawing.Size(386, 100);
            this.PatientsFoundListbox.TabIndex = 0;
            // 
            // LastNameText
            // 
            this.LastNameText.Location = new System.Drawing.Point(133, 41);
            this.LastNameText.Name = "LastNameText";
            this.LastNameText.Size = new System.Drawing.Size(176, 31);
            this.LastNameText.TabIndex = 1;
            // 
            // LastNameLabel
            // 
            this.LastNameLabel.AutoSize = true;
            this.LastNameLabel.Location = new System.Drawing.Point(12, 44);
            this.LastNameLabel.Name = "LastNameLabel";
            this.LastNameLabel.Size = new System.Drawing.Size(115, 25);
            this.LastNameLabel.TabIndex = 2;
            this.LastNameLabel.Text = "Last Name";
            // 
            // SearchButton
            // 
            this.SearchButton.Location = new System.Drawing.Point(315, 41);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(88, 33);
            this.SearchButton.TabIndex = 3;
            this.SearchButton.Text = "Search";
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // FirstNameInsLabel
            // 
            this.FirstNameInsLabel.AutoSize = true;
            this.FirstNameInsLabel.Location = new System.Drawing.Point(452, 124);
            this.FirstNameInsLabel.Name = "FirstNameInsLabel";
            this.FirstNameInsLabel.Size = new System.Drawing.Size(116, 25);
            this.FirstNameInsLabel.TabIndex = 5;
            this.FirstNameInsLabel.Text = "First Name";
            // 
            // FirstNameInsTextBox
            // 
            this.FirstNameInsTextBox.Location = new System.Drawing.Point(594, 121);
            this.FirstNameInsTextBox.Name = "FirstNameInsTextBox";
            this.FirstNameInsTextBox.Size = new System.Drawing.Size(209, 31);
            this.FirstNameInsTextBox.TabIndex = 4;
            // 
            // MiddleNameInsLabel
            // 
            this.MiddleNameInsLabel.AutoSize = true;
            this.MiddleNameInsLabel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.MiddleNameInsLabel.Location = new System.Drawing.Point(452, 161);
            this.MiddleNameInsLabel.Name = "MiddleNameInsLabel";
            this.MiddleNameInsLabel.Size = new System.Drawing.Size(138, 25);
            this.MiddleNameInsLabel.TabIndex = 7;
            this.MiddleNameInsLabel.Text = "Middle Name";
            // 
            // MiddleNameInsTextBox
            // 
            this.MiddleNameInsTextBox.Location = new System.Drawing.Point(594, 158);
            this.MiddleNameInsTextBox.Name = "MiddleNameInsTextBox";
            this.MiddleNameInsTextBox.Size = new System.Drawing.Size(209, 31);
            this.MiddleNameInsTextBox.TabIndex = 6;
            // 
            // NameSuffixInsLabel
            // 
            this.NameSuffixInsLabel.AutoSize = true;
            this.NameSuffixInsLabel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.NameSuffixInsLabel.Location = new System.Drawing.Point(452, 87);
            this.NameSuffixInsLabel.Name = "NameSuffixInsLabel";
            this.NameSuffixInsLabel.Size = new System.Drawing.Size(128, 25);
            this.NameSuffixInsLabel.TabIndex = 11;
            this.NameSuffixInsLabel.Text = "Name Suffix";
            // 
            // NameSuffixInsTextBox
            // 
            this.NameSuffixInsTextBox.Location = new System.Drawing.Point(593, 84);
            this.NameSuffixInsTextBox.Name = "NameSuffixInsTextBox";
            this.NameSuffixInsTextBox.Size = new System.Drawing.Size(53, 31);
            this.NameSuffixInsTextBox.TabIndex = 10;
            // 
            // LastNameInsLabel
            // 
            this.LastNameInsLabel.AutoSize = true;
            this.LastNameInsLabel.Location = new System.Drawing.Point(452, 198);
            this.LastNameInsLabel.Name = "LastNameInsLabel";
            this.LastNameInsLabel.Size = new System.Drawing.Size(115, 25);
            this.LastNameInsLabel.TabIndex = 9;
            this.LastNameInsLabel.Text = "Last Name";
            // 
            // LastNameInsTextBox
            // 
            this.LastNameInsTextBox.Location = new System.Drawing.Point(594, 195);
            this.LastNameInsTextBox.Name = "LastNameInsTextBox";
            this.LastNameInsTextBox.Size = new System.Drawing.Size(209, 31);
            this.LastNameInsTextBox.TabIndex = 8;
            // 
            // InsertRecordButton
            // 
            this.InsertRecordButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InsertRecordButton.Location = new System.Drawing.Point(540, 488);
            this.InsertRecordButton.Name = "InsertRecordButton";
            this.InsertRecordButton.Size = new System.Drawing.Size(88, 33);
            this.InsertRecordButton.TabIndex = 12;
            this.InsertRecordButton.Text = "Insert";
            this.InsertRecordButton.UseVisualStyleBackColor = true;
            this.InsertRecordButton.Click += new System.EventHandler(this.InsertRecordButton_Click);
            // 
            // HSPIdInsLabel
            // 
            this.HSPIdInsLabel.AutoSize = true;
            this.HSPIdInsLabel.Location = new System.Drawing.Point(663, 84);
            this.HSPIdInsLabel.Name = "HSPIdInsLabel";
            this.HSPIdInsLabel.Size = new System.Drawing.Size(81, 25);
            this.HSPIdInsLabel.TabIndex = 20;
            this.HSPIdInsLabel.Text = "HSP ID";
            // 
            // HSPIdInsTextBox
            // 
            this.HSPIdInsTextBox.Location = new System.Drawing.Point(744, 81);
            this.HSPIdInsTextBox.Name = "HSPIdInsTextBox";
            this.HSPIdInsTextBox.Size = new System.Drawing.Size(59, 31);
            this.HSPIdInsTextBox.TabIndex = 19;
            // 
            // GenderInsLabel
            // 
            this.GenderInsLabel.AutoSize = true;
            this.GenderInsLabel.Location = new System.Drawing.Point(505, 368);
            this.GenderInsLabel.Name = "GenderInsLabel";
            this.GenderInsLabel.Size = new System.Drawing.Size(83, 25);
            this.GenderInsLabel.TabIndex = 18;
            this.GenderInsLabel.Text = "Gender";
            // 
            // GenderInsTextBox
            // 
            this.GenderInsTextBox.Location = new System.Drawing.Point(594, 367);
            this.GenderInsTextBox.Name = "GenderInsTextBox";
            this.GenderInsTextBox.Size = new System.Drawing.Size(209, 31);
            this.GenderInsTextBox.TabIndex = 17;
            // 
            // SSNInsLabel
            // 
            this.SSNInsLabel.AutoSize = true;
            this.SSNInsLabel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.SSNInsLabel.Location = new System.Drawing.Point(452, 234);
            this.SSNInsLabel.Name = "SSNInsLabel";
            this.SSNInsLabel.Size = new System.Drawing.Size(55, 25);
            this.SSNInsLabel.TabIndex = 16;
            this.SSNInsLabel.Text = "SSN";
            // 
            // SSNInsTextBox
            // 
            this.SSNInsTextBox.Location = new System.Drawing.Point(508, 231);
            this.SSNInsTextBox.Name = "SSNInsTextBox";
            this.SSNInsTextBox.Size = new System.Drawing.Size(138, 31);
            this.SSNInsTextBox.TabIndex = 15;
            // 
            // LocationIdInsLabel
            // 
            this.LocationIdInsLabel.AutoSize = true;
            this.LocationIdInsLabel.Location = new System.Drawing.Point(572, 47);
            this.LocationIdInsLabel.Name = "LocationIdInsLabel";
            this.LocationIdInsLabel.Size = new System.Drawing.Size(120, 25);
            this.LocationIdInsLabel.TabIndex = 14;
            this.LocationIdInsLabel.Text = "Location ID";
            // 
            // LocationIdInsTextBox
            // 
            this.LocationIdInsTextBox.Location = new System.Drawing.Point(698, 44);
            this.LocationIdInsTextBox.Name = "LocationIdInsTextBox";
            this.LocationIdInsTextBox.Size = new System.Drawing.Size(105, 31);
            this.LocationIdInsTextBox.TabIndex = 13;
            // 
            // PrimaryPhoneInsLabel
            // 
            this.PrimaryPhoneInsLabel.AutoSize = true;
            this.PrimaryPhoneInsLabel.Location = new System.Drawing.Point(20, 284);
            this.PrimaryPhoneInsLabel.Name = "PrimaryPhoneInsLabel";
            this.PrimaryPhoneInsLabel.Size = new System.Drawing.Size(171, 25);
            this.PrimaryPhoneInsLabel.TabIndex = 34;
            this.PrimaryPhoneInsLabel.Text = "Primary Phone #";
            // 
            // PrimaryPhoneInsTextBox
            // 
            this.PrimaryPhoneInsTextBox.Location = new System.Drawing.Point(242, 281);
            this.PrimaryPhoneInsTextBox.Name = "PrimaryPhoneInsTextBox";
            this.PrimaryPhoneInsTextBox.Size = new System.Drawing.Size(135, 31);
            this.PrimaryPhoneInsTextBox.TabIndex = 33;
            // 
            // DODInsLabel
            // 
            this.DODInsLabel.AutoSize = true;
            this.DODInsLabel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.DODInsLabel.Location = new System.Drawing.Point(588, 333);
            this.DODInsLabel.Name = "DODInsLabel";
            this.DODInsLabel.Size = new System.Drawing.Size(58, 25);
            this.DODInsLabel.TabIndex = 32;
            this.DODInsLabel.Text = "DOD";
            // 
            // DODInsTextBox
            // 
            this.DODInsTextBox.Location = new System.Drawing.Point(648, 330);
            this.DODInsTextBox.Name = "DODInsTextBox";
            this.DODInsTextBox.Size = new System.Drawing.Size(155, 31);
            this.DODInsTextBox.TabIndex = 31;
            // 
            // AgeInsLabel
            // 
            this.AgeInsLabel.AutoSize = true;
            this.AgeInsLabel.Location = new System.Drawing.Point(699, 234);
            this.AgeInsLabel.Name = "AgeInsLabel";
            this.AgeInsLabel.Size = new System.Drawing.Size(50, 25);
            this.AgeInsLabel.TabIndex = 30;
            this.AgeInsLabel.Text = "Age";
            // 
            // AgeInsTextBox
            // 
            this.AgeInsTextBox.Location = new System.Drawing.Point(755, 231);
            this.AgeInsTextBox.Name = "AgeInsTextBox";
            this.AgeInsTextBox.Size = new System.Drawing.Size(48, 31);
            this.AgeInsTextBox.TabIndex = 29;
            // 
            // DOBInsLabel
            // 
            this.DOBInsLabel.AutoSize = true;
            this.DOBInsLabel.Location = new System.Drawing.Point(589, 296);
            this.DOBInsLabel.Name = "DOBInsLabel";
            this.DOBInsLabel.Size = new System.Drawing.Size(57, 25);
            this.DOBInsLabel.TabIndex = 28;
            this.DOBInsLabel.Text = "DOB";
            // 
            // DOBInsTextBox
            // 
            this.DOBInsTextBox.Location = new System.Drawing.Point(648, 293);
            this.DOBInsTextBox.Name = "DOBInsTextBox";
            this.DOBInsTextBox.Size = new System.Drawing.Size(155, 31);
            this.DOBInsTextBox.TabIndex = 27;
            // 
            // InsuranceInsLabel
            // 
            this.InsuranceInsLabel.AutoSize = true;
            this.InsuranceInsLabel.Location = new System.Drawing.Point(482, 405);
            this.InsuranceInsLabel.Name = "InsuranceInsLabel";
            this.InsuranceInsLabel.Size = new System.Drawing.Size(106, 25);
            this.InsuranceInsLabel.TabIndex = 26;
            this.InsuranceInsLabel.Text = "Insurance";
            // 
            // InsuranceInsTextBox
            // 
            this.InsuranceInsTextBox.Location = new System.Drawing.Point(594, 404);
            this.InsuranceInsTextBox.Name = "InsuranceInsTextBox";
            this.InsuranceInsTextBox.Size = new System.Drawing.Size(209, 31);
            this.InsuranceInsTextBox.TabIndex = 25;
            // 
            // HeightOnlyInInchesInsLabel
            // 
            this.HeightOnlyInInchesInsLabel.AutoSize = true;
            this.HeightOnlyInInchesInsLabel.Location = new System.Drawing.Point(423, 333);
            this.HeightOnlyInInchesInsLabel.Name = "HeightOnlyInInchesInsLabel";
            this.HeightOnlyInInchesInsLabel.Size = new System.Drawing.Size(111, 25);
            this.HeightOnlyInInchesInsLabel.TabIndex = 24;
            this.HeightOnlyInInchesInsLabel.Text = "Height (in)";
            // 
            // HeightOnlyInInchesInsTextBox
            // 
            this.HeightOnlyInInchesInsTextBox.Location = new System.Drawing.Point(534, 330);
            this.HeightOnlyInInchesInsTextBox.Name = "HeightOnlyInInchesInsTextBox";
            this.HeightOnlyInInchesInsTextBox.Size = new System.Drawing.Size(48, 31);
            this.HeightOnlyInInchesInsTextBox.TabIndex = 23;
            // 
            // WeightInLbsInsLabel
            // 
            this.WeightInLbsInsLabel.AutoSize = true;
            this.WeightInLbsInsLabel.Location = new System.Drawing.Point(407, 296);
            this.WeightInLbsInsLabel.Name = "WeightInLbsInsLabel";
            this.WeightInLbsInsLabel.Size = new System.Drawing.Size(127, 25);
            this.WeightInLbsInsLabel.TabIndex = 22;
            this.WeightInLbsInsLabel.Text = "Weight (lbs)";
            // 
            // WeightInLbsInsTextBox
            // 
            this.WeightInLbsInsTextBox.Location = new System.Drawing.Point(534, 293);
            this.WeightInLbsInsTextBox.Name = "WeightInLbsInsTextBox";
            this.WeightInLbsInsTextBox.Size = new System.Drawing.Size(48, 31);
            this.WeightInLbsInsTextBox.TabIndex = 21;
            // 
            // SecondaryPhoneInsLabel
            // 
            this.SecondaryPhoneInsLabel.AutoSize = true;
            this.SecondaryPhoneInsLabel.Location = new System.Drawing.Point(20, 321);
            this.SecondaryPhoneInsLabel.Name = "SecondaryPhoneInsLabel";
            this.SecondaryPhoneInsLabel.Size = new System.Drawing.Size(201, 25);
            this.SecondaryPhoneInsLabel.TabIndex = 36;
            this.SecondaryPhoneInsLabel.Text = "Secondary Phone #";
            // 
            // SecondaryPhoneInsTextBox
            // 
            this.SecondaryPhoneInsTextBox.Location = new System.Drawing.Point(242, 318);
            this.SecondaryPhoneInsTextBox.Name = "SecondaryPhoneInsTextBox";
            this.SecondaryPhoneInsTextBox.Size = new System.Drawing.Size(135, 31);
            this.SecondaryPhoneInsTextBox.TabIndex = 35;
            // 
            // EmergencyContactPhoneInsLabel
            // 
            this.EmergencyContactPhoneInsLabel.AutoSize = true;
            this.EmergencyContactPhoneInsLabel.Location = new System.Drawing.Point(20, 358);
            this.EmergencyContactPhoneInsLabel.Name = "EmergencyContactPhoneInsLabel";
            this.EmergencyContactPhoneInsLabel.Size = new System.Drawing.Size(200, 50);
            this.EmergencyContactPhoneInsLabel.TabIndex = 38;
            this.EmergencyContactPhoneInsLabel.Text = "Emergency Contact\r\nPhone #";
            // 
            // EmergencyContactPhoneInsTextBox
            // 
            this.EmergencyContactPhoneInsTextBox.Location = new System.Drawing.Point(242, 355);
            this.EmergencyContactPhoneInsTextBox.Name = "EmergencyContactPhoneInsTextBox";
            this.EmergencyContactPhoneInsTextBox.Size = new System.Drawing.Size(135, 31);
            this.EmergencyContactPhoneInsTextBox.TabIndex = 37;
            // 
            // StreetAddrInsLabel
            // 
            this.StreetAddrInsLabel.AutoSize = true;
            this.StreetAddrInsLabel.Location = new System.Drawing.Point(17, 455);
            this.StreetAddrInsLabel.Name = "StreetAddrInsLabel";
            this.StreetAddrInsLabel.Size = new System.Drawing.Size(126, 25);
            this.StreetAddrInsLabel.TabIndex = 42;
            this.StreetAddrInsLabel.Text = "Street Addr.";
            // 
            // StreetAddrInsTextBox
            // 
            this.StreetAddrInsTextBox.Location = new System.Drawing.Point(149, 452);
            this.StreetAddrInsTextBox.Name = "StreetAddrInsTextBox";
            this.StreetAddrInsTextBox.Size = new System.Drawing.Size(301, 31);
            this.StreetAddrInsTextBox.TabIndex = 41;
            // 
            // CityAddrInsLabel
            // 
            this.CityAddrInsLabel.AutoSize = true;
            this.CityAddrInsLabel.Location = new System.Drawing.Point(17, 492);
            this.CityAddrInsLabel.Name = "CityAddrInsLabel";
            this.CityAddrInsLabel.Size = new System.Drawing.Size(49, 25);
            this.CityAddrInsLabel.TabIndex = 44;
            this.CityAddrInsLabel.Text = "City";
            // 
            // CityAddrInsTextBox
            // 
            this.CityAddrInsTextBox.Location = new System.Drawing.Point(72, 486);
            this.CityAddrInsTextBox.Name = "CityAddrInsTextBox";
            this.CityAddrInsTextBox.Size = new System.Drawing.Size(223, 31);
            this.CityAddrInsTextBox.TabIndex = 43;
            // 
            // StateAbbreviationAddrInsLabel
            // 
            this.StateAbbreviationAddrInsLabel.AutoSize = true;
            this.StateAbbreviationAddrInsLabel.Location = new System.Drawing.Point(17, 526);
            this.StateAbbreviationAddrInsLabel.Name = "StateAbbreviationAddrInsLabel";
            this.StateAbbreviationAddrInsLabel.Size = new System.Drawing.Size(119, 25);
            this.StateAbbreviationAddrInsLabel.TabIndex = 46;
            this.StateAbbreviationAddrInsLabel.Text = "State Abbr.";
            // 
            // StateAbbreviationAddrInsTextBox
            // 
            this.StateAbbreviationAddrInsTextBox.Location = new System.Drawing.Point(138, 523);
            this.StateAbbreviationAddrInsTextBox.Name = "StateAbbreviationAddrInsTextBox";
            this.StateAbbreviationAddrInsTextBox.Size = new System.Drawing.Size(83, 31);
            this.StateAbbreviationAddrInsTextBox.TabIndex = 45;
            // 
            // ZipCodeAddrInsLabel
            // 
            this.ZipCodeAddrInsLabel.AutoSize = true;
            this.ZipCodeAddrInsLabel.Location = new System.Drawing.Point(227, 526);
            this.ZipCodeAddrInsLabel.Name = "ZipCodeAddrInsLabel";
            this.ZipCodeAddrInsLabel.Size = new System.Drawing.Size(99, 25);
            this.ZipCodeAddrInsLabel.TabIndex = 48;
            this.ZipCodeAddrInsLabel.Text = "Zip Code";
            // 
            // ZipCodeAddrInsTextBox
            // 
            this.ZipCodeAddrInsTextBox.Location = new System.Drawing.Point(331, 523);
            this.ZipCodeAddrInsTextBox.Name = "ZipCodeAddrInsTextBox";
            this.ZipCodeAddrInsTextBox.Size = new System.Drawing.Size(119, 31);
            this.ZipCodeAddrInsTextBox.TabIndex = 47;
            // 
            // PatientAddressInfoLabel
            // 
            this.PatientAddressInfoLabel.AutoSize = true;
            this.PatientAddressInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PatientAddressInfoLabel.Location = new System.Drawing.Point(118, 424);
            this.PatientAddressInfoLabel.Name = "PatientAddressInfoLabel";
            this.PatientAddressInfoLabel.Size = new System.Drawing.Size(225, 25);
            this.PatientAddressInfoLabel.TabIndex = 49;
            this.PatientAddressInfoLabel.Text = "Patient Address Info";
            // 
            // PatientContactInfoLabel
            // 
            this.PatientContactInfoLabel.AutoSize = true;
            this.PatientContactInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PatientContactInfoLabel.Location = new System.Drawing.Point(17, 252);
            this.PatientContactInfoLabel.Name = "PatientContactInfoLabel";
            this.PatientContactInfoLabel.Size = new System.Drawing.Size(220, 25);
            this.PatientContactInfoLabel.TabIndex = 50;
            this.PatientContactInfoLabel.Text = "Patient Contact Info";
            // 
            // PatientPatientInfoLabel
            // 
            this.PatientPatientInfoLabel.AutoSize = true;
            this.PatientPatientInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PatientPatientInfoLabel.Location = new System.Drawing.Point(514, 14);
            this.PatientPatientInfoLabel.Name = "PatientPatientInfoLabel";
            this.PatientPatientInfoLabel.Size = new System.Drawing.Size(232, 25);
            this.PatientPatientInfoLabel.TabIndex = 51;
            this.PatientPatientInfoLabel.Text = "Patient Personal Info";
            // 
            // NewPatientLabel
            // 
            this.NewPatientLabel.AutoSize = true;
            this.NewPatientLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewPatientLabel.Location = new System.Drawing.Point(627, 492);
            this.NewPatientLabel.Name = "NewPatientLabel";
            this.NewPatientLabel.Size = new System.Drawing.Size(138, 25);
            this.NewPatientLabel.TabIndex = 52;
            this.NewPatientLabel.Text = "New Patient";
            // 
            // SearchForExistingPatientsLabel
            // 
            this.SearchForExistingPatientsLabel.AutoSize = true;
            this.SearchForExistingPatientsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchForExistingPatientsLabel.Location = new System.Drawing.Point(49, 13);
            this.SearchForExistingPatientsLabel.Name = "SearchForExistingPatientsLabel";
            this.SearchForExistingPatientsLabel.Size = new System.Drawing.Size(328, 25);
            this.SearchForExistingPatientsLabel.TabIndex = 53;
            this.SearchForExistingPatientsLabel.Text = "Search For Existing Patient(s)";
            // 
            // ContactLabel
            // 
            this.ContactLabel.AutoSize = true;
            this.ContactLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ContactLabel.Location = new System.Drawing.Point(231, 252);
            this.ContactLabel.Name = "ContactLabel";
            this.ContactLabel.Size = new System.Drawing.Size(132, 24);
            this.ContactLabel.TabIndex = 54;
            this.ContactLabel.Text = ": (##########)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(551, 266);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(252, 24);
            this.label1.TabIndex = 55;
            this.label1.Text = "Date Format: (YYYY-MM-DD)";
            // 
            // SearchResultsLabel
            // 
            this.SearchResultsLabel.AutoSize = true;
            this.SearchResultsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchResultsLabel.Location = new System.Drawing.Point(18, 79);
            this.SearchResultsLabel.Name = "SearchResultsLabel";
            this.SearchResultsLabel.Size = new System.Drawing.Size(359, 24);
            this.SearchResultsLabel.TabIndex = 56;
            this.SearchResultsLabel.Text = "[PatientId] (Suffix) FName MName LName";
            // 
            // BlueNoticeLabel
            // 
            this.BlueNoticeLabel.AutoSize = true;
            this.BlueNoticeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BlueNoticeLabel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.BlueNoticeLabel.Location = new System.Drawing.Point(472, 534);
            this.BlueNoticeLabel.Name = "BlueNoticeLabel";
            this.BlueNoticeLabel.Size = new System.Drawing.Size(331, 24);
            this.BlueNoticeLabel.TabIndex = 57;
            this.BlueNoticeLabel.Text = "*Anything BLUE can be left empty*";
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(815, 567);
            this.Controls.Add(this.BlueNoticeLabel);
            this.Controls.Add(this.SearchResultsLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ContactLabel);
            this.Controls.Add(this.SearchForExistingPatientsLabel);
            this.Controls.Add(this.NewPatientLabel);
            this.Controls.Add(this.PatientPatientInfoLabel);
            this.Controls.Add(this.PatientContactInfoLabel);
            this.Controls.Add(this.PatientAddressInfoLabel);
            this.Controls.Add(this.ZipCodeAddrInsLabel);
            this.Controls.Add(this.ZipCodeAddrInsTextBox);
            this.Controls.Add(this.StateAbbreviationAddrInsLabel);
            this.Controls.Add(this.StateAbbreviationAddrInsTextBox);
            this.Controls.Add(this.CityAddrInsLabel);
            this.Controls.Add(this.CityAddrInsTextBox);
            this.Controls.Add(this.StreetAddrInsLabel);
            this.Controls.Add(this.StreetAddrInsTextBox);
            this.Controls.Add(this.EmergencyContactPhoneInsLabel);
            this.Controls.Add(this.EmergencyContactPhoneInsTextBox);
            this.Controls.Add(this.SecondaryPhoneInsLabel);
            this.Controls.Add(this.SecondaryPhoneInsTextBox);
            this.Controls.Add(this.PrimaryPhoneInsLabel);
            this.Controls.Add(this.PrimaryPhoneInsTextBox);
            this.Controls.Add(this.DODInsLabel);
            this.Controls.Add(this.DODInsTextBox);
            this.Controls.Add(this.AgeInsLabel);
            this.Controls.Add(this.AgeInsTextBox);
            this.Controls.Add(this.DOBInsLabel);
            this.Controls.Add(this.DOBInsTextBox);
            this.Controls.Add(this.InsuranceInsLabel);
            this.Controls.Add(this.InsuranceInsTextBox);
            this.Controls.Add(this.HeightOnlyInInchesInsLabel);
            this.Controls.Add(this.HeightOnlyInInchesInsTextBox);
            this.Controls.Add(this.WeightInLbsInsLabel);
            this.Controls.Add(this.WeightInLbsInsTextBox);
            this.Controls.Add(this.HSPIdInsLabel);
            this.Controls.Add(this.HSPIdInsTextBox);
            this.Controls.Add(this.GenderInsLabel);
            this.Controls.Add(this.GenderInsTextBox);
            this.Controls.Add(this.SSNInsLabel);
            this.Controls.Add(this.SSNInsTextBox);
            this.Controls.Add(this.LocationIdInsLabel);
            this.Controls.Add(this.LocationIdInsTextBox);
            this.Controls.Add(this.InsertRecordButton);
            this.Controls.Add(this.NameSuffixInsLabel);
            this.Controls.Add(this.NameSuffixInsTextBox);
            this.Controls.Add(this.LastNameInsLabel);
            this.Controls.Add(this.LastNameInsTextBox);
            this.Controls.Add(this.MiddleNameInsLabel);
            this.Controls.Add(this.MiddleNameInsTextBox);
            this.Controls.Add(this.FirstNameInsLabel);
            this.Controls.Add(this.FirstNameInsTextBox);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.LastNameLabel);
            this.Controls.Add(this.LastNameText);
            this.Controls.Add(this.PatientsFoundListbox);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Dashboard";
            this.Text = "Patients Search/Insert";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox PatientsFoundListbox;
        private System.Windows.Forms.TextBox LastNameText;
        private System.Windows.Forms.Label LastNameLabel;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.Label FirstNameInsLabel;
        private System.Windows.Forms.TextBox FirstNameInsTextBox;
        private System.Windows.Forms.Label MiddleNameInsLabel;
        private System.Windows.Forms.TextBox MiddleNameInsTextBox;
        private System.Windows.Forms.Label NameSuffixInsLabel;
        private System.Windows.Forms.TextBox NameSuffixInsTextBox;
        private System.Windows.Forms.Label LastNameInsLabel;
        private System.Windows.Forms.TextBox LastNameInsTextBox;
        private System.Windows.Forms.Button InsertRecordButton;
        private System.Windows.Forms.Label HSPIdInsLabel;
        private System.Windows.Forms.TextBox HSPIdInsTextBox;
        private System.Windows.Forms.Label GenderInsLabel;
        private System.Windows.Forms.TextBox GenderInsTextBox;
        private System.Windows.Forms.Label SSNInsLabel;
        private System.Windows.Forms.TextBox SSNInsTextBox;
        private System.Windows.Forms.Label LocationIdInsLabel;
        private System.Windows.Forms.TextBox LocationIdInsTextBox;
        private System.Windows.Forms.Label PrimaryPhoneInsLabel;
        private System.Windows.Forms.TextBox PrimaryPhoneInsTextBox;
        private System.Windows.Forms.Label DODInsLabel;
        private System.Windows.Forms.TextBox DODInsTextBox;
        private System.Windows.Forms.Label AgeInsLabel;
        private System.Windows.Forms.TextBox AgeInsTextBox;
        private System.Windows.Forms.Label DOBInsLabel;
        private System.Windows.Forms.TextBox DOBInsTextBox;
        private System.Windows.Forms.Label InsuranceInsLabel;
        private System.Windows.Forms.TextBox InsuranceInsTextBox;
        private System.Windows.Forms.Label HeightOnlyInInchesInsLabel;
        private System.Windows.Forms.TextBox HeightOnlyInInchesInsTextBox;
        private System.Windows.Forms.Label WeightInLbsInsLabel;
        private System.Windows.Forms.TextBox WeightInLbsInsTextBox;
        private System.Windows.Forms.Label SecondaryPhoneInsLabel;
        private System.Windows.Forms.TextBox SecondaryPhoneInsTextBox;
        private System.Windows.Forms.Label EmergencyContactPhoneInsLabel;
        private System.Windows.Forms.TextBox EmergencyContactPhoneInsTextBox;
        private System.Windows.Forms.Label StreetAddrInsLabel;
        private System.Windows.Forms.TextBox StreetAddrInsTextBox;
        private System.Windows.Forms.Label CityAddrInsLabel;
        private System.Windows.Forms.TextBox CityAddrInsTextBox;
        private System.Windows.Forms.Label StateAbbreviationAddrInsLabel;
        private System.Windows.Forms.TextBox StateAbbreviationAddrInsTextBox;
        private System.Windows.Forms.Label ZipCodeAddrInsLabel;
        private System.Windows.Forms.TextBox ZipCodeAddrInsTextBox;
        private System.Windows.Forms.Label PatientAddressInfoLabel;
        private System.Windows.Forms.Label PatientContactInfoLabel;
        private System.Windows.Forms.Label PatientPatientInfoLabel;
        private System.Windows.Forms.Label NewPatientLabel;
        private System.Windows.Forms.Label SearchForExistingPatientsLabel;
        private System.Windows.Forms.Label ContactLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label SearchResultsLabel;
        private System.Windows.Forms.Label BlueNoticeLabel;
    }
}

